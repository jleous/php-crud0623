<?php
session_start();

$conn = mysqli_connect('localhost', 'root', '', 'php_crud_task_2023');
if (isset($conn)) {
   /*  echo 'Conected'; */
}
